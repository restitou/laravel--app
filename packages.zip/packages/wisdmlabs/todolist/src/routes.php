<?php
Route::resource('/task', 'Wisdmlabs\Todolist\TaskController');

?>